﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OPenDoor : MonoBehaviour
{
    public GameObject blueDoor;
    public GameObject redDoor;
    public GameObject yellowDoor;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Player" && collision.gameObject.name == "Claire")
        {
            this.GetComponent<Renderer>().material.color = new Color(31f/255f,99f/255f,161f/255f);
            blueDoor.gameObject.SetActive(false);
           
            
        }

        if (collision.gameObject.tag == "Player" && collision.gameObject.name == "John")
        {
            yellowDoor.gameObject.SetActive(false);
            this.GetComponent<Renderer>().material.color = new Color(225f / 255f, 229f / 255f, 53f / 255f);
        }

        if (collision.gameObject.tag == "Player" && collision.gameObject.name == "Thomas")
        {
            redDoor.gameObject.SetActive(false);
            this.GetComponent<Renderer>().material.color = new Color(233f / 255f, 101f / 255f, 101f / 255f);
        }
    }
}
