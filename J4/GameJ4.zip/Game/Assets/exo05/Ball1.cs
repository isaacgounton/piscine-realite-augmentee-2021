﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball1 : MonoBehaviour
{
    public float speed;
    private Vector3 direction;
    private Vector3 spawnPoint;

    [SerializeField]
    int playerOneScore;
    [SerializeField]
    int playerTwoScore;


    // Start is called before the first frame update
    void Start()
    {
        this.direction = new Vector3(1f, 0f, 1f);
        spawnPoint = new Vector3(0f, 0.5f, 0f);
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position += direction * speed;
    }

    private void OnCollisionEnter(Collision collision)
    {
        Vector3 normal = collision.contacts[0].normal;
        direction = Vector3.Reflect(direction, normal);

        if (collision.gameObject.name == "WestWall")
        {
            playerTwoScore++;
            transform.position = spawnPoint;
        }


        if (collision.gameObject.name == "EastWall")
        {
            playerOneScore++;
            transform.position = spawnPoint;
        }

        Debug.Log("Player 1: " + playerOneScore + " | " + "Player 2: " + playerTwoScore);
    }
}
