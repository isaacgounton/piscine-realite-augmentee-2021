﻿using UnityEngine;
using System.Collections;

public class Building : MonoBehaviour {

	public int HP;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
